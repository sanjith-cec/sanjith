#include<stdio.h>
int main(){
    //AO - +,-,*,/,%
    int a = 30;
    int b = 20;
    printf("a+b = %d \n",(a+b));
}