#include<stdio.h>
int main(){
    //RO - >, <, >=, <=, ==, !=
    int a= 10;
    int b = 30;
    printf("a>b = %d \n",(a>b));
    printf("a<b = %d \n",(a<b));
    printf("a>=b = %d \na<=b = %d \n",(a>=b),(a<=b));
}