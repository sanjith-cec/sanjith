#include<stdio.h>
int main(){
    char ch;
    printf("Enter a Character: ");
    scanf("%c",&ch);
    printf("Entered Character is: %c \n",ch);
    printf("Ascii Value is: %d",ch);
}