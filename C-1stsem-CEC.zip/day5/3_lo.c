#include<stdio.h> // i->scanf , o ->printf
int main(){
    int a = 1;
    int b = 0;
    printf("a&&b = %d \n",(a&&b));
    printf("a||b = %d \n",(a||b));
    printf("!a = %d \n",(!a));
}