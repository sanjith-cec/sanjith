#include<stdio.h>
int main(){
    int arr[5]={10,20,30,40,50};
    int *ptr = arr;
    printf("Array elements using pointer: \n");
    for(int i=0;i<=4;i++){
        printf("%d ",*ptr);
        ptr++;
    }

}