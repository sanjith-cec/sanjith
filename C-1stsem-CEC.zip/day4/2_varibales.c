#include<stdio.h>
#include<stdbool.h>
int main(){
    int age = 30;
    printf("Your age is: %d", age);
    float marks = 345.34;
    printf("\nYour marks is: %f", marks);
    double pi = 3.14;
    printf("\nValue of pi is: %lf",pi);
    char gender = 'M';
    printf("\n Your \? gender is: %c",gender);
    bool isWalking = false;
    printf("\n Is\"Walk\ting \": %d", isWalking);
}