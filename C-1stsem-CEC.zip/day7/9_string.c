#include<stdio.h>
int main(){
    char input[300];
    printf("Enter a String: ");
    scanf("%s",input);
    printf("Entered String is: %s",input);
}