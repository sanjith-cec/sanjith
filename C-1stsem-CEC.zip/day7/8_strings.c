#include<stdio.h>
int main(){
    // char name[30]="Hello world";
    char name[]="Hello world";
    printf("String is: %s",name);
}