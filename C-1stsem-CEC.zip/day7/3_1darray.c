#include<stdio.h>
int main(){
    int std_marks[3];
    std_marks[0] = 40;
    std_marks[1] = 50;
    std_marks[2] = 60;

    printf("1st %d\n",std_marks[0]);
    printf("2nd %d\n",std_marks[1]);
    printf("3st %d\n",std_marks[2]);
}